#!/data/data/com.termux/files/usr/bin/bash
set -e
if ! command -v java >/dev/null 2>&1; then echo 'Java 17 is required.'; exit 1; fi
if command -v gradle >/dev/null 2>&1; then gradle build; else echo 'Gradle is not installed. Install Gradle 8.x, then run: gradle build'; exit 2; fi
