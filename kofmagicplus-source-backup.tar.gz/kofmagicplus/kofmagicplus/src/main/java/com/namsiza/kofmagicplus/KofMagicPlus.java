package com.namsiza.kofmagicplus;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(KofMagicPlus.MODID)
public class KofMagicPlus {
    public static final String MODID = "kofmagicplus";
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);

    public static final ArmorMaterial RUGAL_MAT = new FighterArmorMaterial("rugal", 18, 2.0f, 0.10f);
    public static final ArmorMaterial RALF_MAT = new FighterArmorMaterial("ralf", 20, 1.0f, 0.15f);
    public static final ArmorMaterial YASHIRO_MAT = new FighterArmorMaterial("yashiro", 24, 2.5f, 0.20f);
    public static final ArmorMaterial BENIMARU_MAT = new FighterArmorMaterial("benimaru", 16, 1.5f, 0.05f);

    public static final RegistryObject<Item> RUGAL_HELMET=armor("rugal_helmet",RUGAL_MAT,ArmorItem.Type.HELMET);
    public static final RegistryObject<Item> RUGAL_CHEST=armor("rugal_chestplate",RUGAL_MAT,ArmorItem.Type.CHESTPLATE);
    public static final RegistryObject<Item> RUGAL_LEGS=armor("rugal_leggings",RUGAL_MAT,ArmorItem.Type.LEGGINGS);
    public static final RegistryObject<Item> RUGAL_BOOTS=armor("rugal_boots",RUGAL_MAT,ArmorItem.Type.BOOTS);
    public static final RegistryObject<Item> RALF_HELMET=armor("ralf_helmet",RALF_MAT,ArmorItem.Type.HELMET);
    public static final RegistryObject<Item> RALF_CHEST=armor("ralf_chestplate",RALF_MAT,ArmorItem.Type.CHESTPLATE);
    public static final RegistryObject<Item> RALF_LEGS=armor("ralf_leggings",RALF_MAT,ArmorItem.Type.LEGGINGS);
    public static final RegistryObject<Item> RALF_BOOTS=armor("ralf_boots",RALF_MAT,ArmorItem.Type.BOOTS);
    public static final RegistryObject<Item> YASHIRO_HELMET=armor("yashiro_helmet",YASHIRO_MAT,ArmorItem.Type.HELMET);
    public static final RegistryObject<Item> YASHIRO_CHEST=armor("yashiro_chestplate",YASHIRO_MAT,ArmorItem.Type.CHESTPLATE);
    public static final RegistryObject<Item> YASHIRO_LEGS=armor("yashiro_leggings",YASHIRO_MAT,ArmorItem.Type.LEGGINGS);
    public static final RegistryObject<Item> YASHIRO_BOOTS=armor("yashiro_boots",YASHIRO_MAT,ArmorItem.Type.BOOTS);
    public static final RegistryObject<Item> BENIMARU_HELMET=armor("benimaru_helmet",BENIMARU_MAT,ArmorItem.Type.HELMET);
    public static final RegistryObject<Item> BENIMARU_CHEST=armor("benimaru_chestplate",BENIMARU_MAT,ArmorItem.Type.CHESTPLATE);
    public static final RegistryObject<Item> BENIMARU_LEGS=armor("benimaru_leggings",BENIMARU_MAT,ArmorItem.Type.LEGGINGS);
    public static final RegistryObject<Item> BENIMARU_BOOTS=armor("benimaru_boots",BENIMARU_MAT,ArmorItem.Type.BOOTS);

    private static RegistryObject<Item> armor(String id, ArmorMaterial mat, ArmorItem.Type type) { return ITEMS.register(id, () -> new ArmorItem(mat,type,new Item.Properties())); }

    public KofMagicPlus() { ITEMS.register(FMLJavaModLoadingContext.get().getModEventBus()); MinecraftForge.EVENT_BUS.register(this); }

    @SubscribeEvent public void commands(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("kof")
            .then(Commands.literal("special").executes(c -> special(c.getSource().getPlayerOrException())))
            .then(Commands.literal("key").then(Commands.argument("slot", StringArgumentType.word()).executes(c -> keyAbility(c.getSource().getPlayerOrException(), StringArgumentType.getString(c,"slot")))))
            .then(Commands.literal("ability").then(Commands.argument("fighter",StringArgumentType.word()).executes(c -> ability(c.getSource().getPlayerOrException(),StringArgumentType.getString(c,"fighter")))))
            .then(Commands.literal("outfit").then(Commands.argument("fighter",StringArgumentType.word()).executes(c -> outfit(c.getSource().getPlayerOrException(),StringArgumentType.getString(c,"fighter")))))
            .then(Commands.literal("help").executes(c->{c.getSource().sendSuccess(()->Component.literal("§6KOF Fighter Pack§r: Wear a full matching outfit, then use /kof special. /kof ability <rugal|ralf|yashiro|benimaru> also works."),false);return 1;})));
    }

    private String worn(ServerPlayer p){
        ItemStack h=p.getInventory().getArmor(3), c=p.getInventory().getArmor(2), l=p.getInventory().getArmor(1), b=p.getInventory().getArmor(0);
        if(h.is(RUGAL_HELMET.get())&&c.is(RUGAL_CHEST.get())&&l.is(RUGAL_LEGS.get())&&b.is(RUGAL_BOOTS.get()))return "rugal";
        if(h.is(RALF_HELMET.get())&&c.is(RALF_CHEST.get())&&l.is(RALF_LEGS.get())&&b.is(RALF_BOOTS.get()))return "ralf";
        if(h.is(YASHIRO_HELMET.get())&&c.is(YASHIRO_CHEST.get())&&l.is(YASHIRO_LEGS.get())&&b.is(YASHIRO_BOOTS.get()))return "yashiro";
        if(h.is(BENIMARU_HELMET.get())&&c.is(BENIMARU_CHEST.get())&&l.is(BENIMARU_LEGS.get())&&b.is(BENIMARU_BOOTS.get()))return "benimaru";
        return "";
    }

    @SubscribeEvent public void tick(TickEvent.PlayerTickEvent e){
        if(e.phase!=TickEvent.Phase.END||e.player.level().isClientSide||e.player.tickCount%20!=0)return;
        ServerPlayer p=(ServerPlayer)e.player; String f=worn(p); if(f.isEmpty())return;
        p.getPersistentData().putString("kof_fighter",f);
        if(f.equals("rugal")) p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,40,1,true,false));
        if(f.equals("ralf")) p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE,40,0,true,false));
        if(f.equals("yashiro")) p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,40,0,true,false));
        if(f.equals("benimaru")) p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED,40,1,true,false));
    }

    private int special(ServerPlayer p){ return keyAbility(p,"v"); }
    private int ability(ServerPlayer p,String f){ f=f.toLowerCase(); switch(f){case "rugal"->rugal(p);case "ralf"->ralf(p);case "yashiro"->yashiro(p);case "benimaru"->benimaru(p);default->{p.sendSystemMessage(Component.literal("§cUnknown fighter."));return 0;}} return 1; }

    private int keyAbility(ServerPlayer p,String slot){
        String f=worn(p);
        if(f.isEmpty()) f=p.getPersistentData().getString("kof_fighter");
        if(f==null||f.isEmpty()){p.sendSystemMessage(Component.literal("§cWear a complete fighter outfit first."));return 0;}
        slot=slot.toLowerCase();
        long now=p.level().getGameTime();
        String key="kof_cd_"+slot;
        long ready=p.getPersistentData().getLong(key);
        if(now<ready)return 0;
        switch(slot){
            case "v" -> { primary(p,f); p.getPersistentData().putLong(key,now+12); }
            case "z" -> { secondary(p,f); p.getPersistentData().putLong(key,now+18); }
            case "x" -> { ultimate(p,f); p.getPersistentData().putLong(key,now+40); }
            case "k" -> { power(p,f); p.getPersistentData().putLong(key,now+80); }
            default -> { return 0; }
        }
        return 1;
    }

    private void primary(ServerPlayer p,String f){ switch(f){case "rugal"->rugal(p);case "ralf"->ralf(p);case "yashiro"->yashiro(p);case "benimaru"->benimaru(p);} }
    private void secondary(ServerPlayer p,String f){
        ServerLevel w=p.serverLevel(); Vec3 d=p.getLookAngle().normalize();
        switch(f){
            case "rugal" -> { p.setDeltaMovement(d.x*1.8,Math.max(.35,d.y*.8),d.z*1.8); p.hurtMarked=true; hurt(w,p,p.position().add(d.scale(1.8)),2.2,12); w.sendParticles(net.minecraft.core.particles.SOUL_FIRE_FLAME,p.getX(),p.getY()+1,p.getZ(),35,.5,.7,.5,.02); }
            case "ralf" -> { for(int i=1;i<5;i++) hurt(w,p,p.position().add(d.scale(i)),1.4,9); w.sendParticles(net.minecraft.core.particles.EXPLOSION,p.getX()+d.x*2,p.getY()+1,p.getZ()+d.z*2,2,0,0,0,0); }
            case "yashiro" -> { hurt(w,p,p.position(),3.5,11); p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE,80,1)); w.sendParticles(net.minecraft.core.particles.CRIT,p.getX(),p.getY()+1,p.getZ(),70,1,1,1,.12); }
            case "benimaru" -> { p.setDeltaMovement(d.x*2.0,1.0,d.z*2.0); p.hurtMarked=true; for(int i=0;i<4;i++) hurt(w,p,p.position().add(d.scale(i)),1.2,8); w.sendParticles(net.minecraft.core.particles.ELECTRIC_SPARK,p.getX(),p.getY()+1,p.getZ(),60,.8,1,.8,.04); }
        }
        p.sendSystemMessage(Component.literal("§e"+f.toUpperCase()+" secondary technique!"));
    }
    private void ultimate(ServerPlayer p,String f){
        ServerLevel w=p.serverLevel(); Vec3 d=p.getLookAngle().normalize();
        double range=5.0; Vec3 center=p.position().add(d.scale(2.5));
        hurt(w,p,center,range,24);
        w.sendParticles(net.minecraft.core.particles.EXPLOSION,center.x,center.y+1,center.z,8,.8,.8,.8,.02);
        w.sendParticles(net.minecraft.core.particles.FLAME,center.x,center.y+1,center.z,180,2,1.5,2,.08);
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,180,3));
        p.sendSystemMessage(Component.literal("§c"+f.toUpperCase()+" MAXIMUM FINISH!"));
    }
    private void power(ServerPlayer p,String f){
        int amp=switch(f){case "rugal"->2;case "ralf"->1;case "yashiro"->2;case "benimaru"->1;default->0;};
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,300,amp));
        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED,300,1));
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE,300,0));
        p.serverLevel().sendParticles(net.minecraft.core.particles.END_ROD,p.getX(),p.getY()+1,p.getZ(),120,1,1.2,1,.05);
        p.sendSystemMessage(Component.literal("§b"+f.toUpperCase()+" POWER MODE!"));
    }

    private void rugal(ServerPlayer p){ServerLevel w=p.serverLevel();Vec3 d=p.getLookAngle().normalize();Vec3 s=p.getEyePosition();for(int i=0;i<24;i++){Vec3 q=s.add(d.scale(i*.55));w.sendParticles(net.minecraft.core.particles.ParticleTypes.SOUL_FIRE_FLAME,q.x,q.y,q.z,7,.12,.12,.12,.01);hurt(w,p,q,.7,10);}p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,160,2));p.sendSystemMessage(Component.literal("§4RUGAL: Genocide Cutter / Dark Impact!"));}
    private void ralf(ServerPlayer p){ServerLevel w=p.serverLevel();Vec3 d=p.getLookAngle().normalize();p.setDeltaMovement(d.x*3.2,Math.max(.7,d.y*1.4),d.z*3.2);p.hurtMarked=true;w.sendParticles(net.minecraft.core.particles.ParticleTypes.EXPLOSION,p.getX(),p.getY()+1,p.getZ(),3,0,0,0,0);hurt(w,p,p.position().add(d.scale(2)),2.6,14);p.sendSystemMessage(Component.literal("§2RALF: Galactica Phantom Rush!"));}
    private void yashiro(ServerPlayer p){ServerLevel w=p.serverLevel();w.sendParticles(net.minecraft.core.particles.ParticleTypes.DRAGON_BREATH,p.getX(),p.getY()+1,p.getZ(),120,1,1,1,.08);hurt(w,p,p.position(),3,16);p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,240,2));p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED,240,1));p.sendSystemMessage(Component.literal("§dYASHIRO: Oniyaki Power Crush!"));}
    private void benimaru(ServerPlayer p){ServerLevel w=p.serverLevel();Vec3 d=p.getLookAngle().normalize();for(int i=0;i<22;i++){Vec3 q=p.getEyePosition().add(d.scale(i*.6));w.sendParticles(net.minecraft.core.particles.ParticleTypes.ELECTRIC_SPARK,q.x,q.y,q.z,10,.15,.15,.15,.03);hurt(w,p,q,.6,8);}p.addEffect(new MobEffectInstance(MobEffects.JUMP,180,2));p.sendSystemMessage(Component.literal("§bBENIMARU: Raijin Ken Thunder Rush!"));}
    private void hurt(ServerLevel w,ServerPlayer p,Vec3 q,double r,float dmg){for(LivingEntity x:w.getEntitiesOfClass(LivingEntity.class,new AABB(q.subtract(r,r,r),q.add(r,r,r)),x->x!=p&&x.isAlive()))x.hurt(w.damageSources().playerAttack(p),dmg);}

    private int outfit(ServerPlayer p,String f){Item[] a=switch(f.toLowerCase()){case "rugal"->new Item[]{RUGAL_HELMET.get(),RUGAL_CHEST.get(),RUGAL_LEGS.get(),RUGAL_BOOTS.get()};case "ralf"->new Item[]{RALF_HELMET.get(),RALF_CHEST.get(),RALF_LEGS.get(),RALF_BOOTS.get()};case "yashiro"->new Item[]{YASHIRO_HELMET.get(),YASHIRO_CHEST.get(),YASHIRO_LEGS.get(),YASHIRO_BOOTS.get()};case "benimaru"->new Item[]{BENIMARU_HELMET.get(),BENIMARU_CHEST.get(),BENIMARU_LEGS.get(),BENIMARU_BOOTS.get()};default->null;};if(a==null){p.sendSystemMessage(Component.literal("§cUnknown fighter."));return 0;}for(Item i:a)p.getInventory().placeItemBackInInventory(new ItemStack(i));p.sendSystemMessage(Component.literal("§aFull original "+f+" outfit added. Wear all four pieces to unlock its powers."));return 1;}

    @SubscribeEvent public void join(PlayerEvent.PlayerLoggedInEvent e){if(!e.getEntity().level().isClientSide)e.getEntity().sendSystemMessage(Component.literal("§6KOF Fighter Pack§r: §e/kof help"));}

    static class FighterArmorMaterial implements ArmorMaterial {
        private final String name; private final int durability; private final float toughness, kb;
        FighterArmorMaterial(String n,int d,float t,float k){name=n;durability=d;toughness=t;kb=k;}
        public int getDurabilityForType(ArmorItem.Type t){return durability*t.getDurability(1);}
        public int getDefenseForType(ArmorItem.Type t){return switch(t){case BOOTS->2;case LEGGINGS->5;case CHESTPLATE->7;case HELMET->2;};}
        public int getEnchantmentValue(){return 12;}
        public net.minecraft.sounds.SoundEvent getEquipSound(){return SoundEvents.ARMOR_EQUIP_LEATHER;}
        public Ingredient getRepairIngredient(){return Ingredient.of(net.minecraft.world.item.Items.IRON_INGOT);}
        public String getName(){return MODID+":"+name;}
        public float getToughness(){return toughness;}
        public float getKnockbackResistance(){return kb;}
    }
}
