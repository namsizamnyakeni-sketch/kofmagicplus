Corrected Forge 1.20.1 MDK configuration. In Termux, copy this project into your home directory, ensure gradle/wrapper/gradle-wrapper.jar exists, then run ./gradlew build.
