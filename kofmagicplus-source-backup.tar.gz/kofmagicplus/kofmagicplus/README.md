# KOF Magic Plus Style - Forge 1.20.1

Original fan-made Minecraft Java Forge 1.20.1 mod project.

## Fighters
- Rugal
- Ralf
- Yashiro
- Benimaru

Each fighter has an original four-piece outfit. Wearing all four matching pieces unlocks that fighter's powers.

## Keybinds
- **V** - Primary ability
- **Z** - Secondary technique
- **X** - Maximum/finisher attack
- **K** - Power Mode

The keys use the abilities of the fighter whose complete outfit you are wearing.

## Build
Requires **Java 17** and a ForgeGradle-compatible Gradle 8.x installation. Run:

    gradle build

The finished mod will be in `build/libs/`.

For Termux, run `./build-termux.sh` after installing Java 17 and Gradle.

This project uses original textures/effects and does not contain the original game's copyrighted sprite sheets.
