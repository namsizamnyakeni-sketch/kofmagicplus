package com.namsiza.kofmagicplus;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = KofMagicPlus.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = net.minecraftforge.api.distmarker.Dist.CLIENT)
public class KofMagicPlusClient {
    public static final KeyMapping V = new KeyMapping("key.kofmagicplus.v", KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_V, "key.categories.kofmagicplus");
    public static final KeyMapping Z = new KeyMapping("key.kofmagicplus.z", KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_Z, "key.categories.kofmagicplus");
    public static final KeyMapping X = new KeyMapping("key.kofmagicplus.x", KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_X, "key.categories.kofmagicplus");
    public static final KeyMapping K = new KeyMapping("key.kofmagicplus.k", KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_K, "key.categories.kofmagicplus");

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        event.register(V); event.register(Z); event.register(X); event.register(K);
        MinecraftForge.EVENT_BUS.register(KofMagicPlusClient.class);
    }

    @SubscribeEvent
    public static void keyInput(InputEvent.Key event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.screen != null || event.getAction() != GLFW.GLFW_PRESS) return;
        if (V.matches(event.getKey(), event.getScanCode())) send("v");
        else if (Z.matches(event.getKey(), event.getScanCode())) send("z");
        else if (X.matches(event.getKey(), event.getScanCode())) send("x");
        else if (K.matches(event.getKey(), event.getScanCode())) send("k");
    }

    private static void send(String slot) { Minecraft.getInstance().player.connection.sendCommand("kof key " + slot); }
}
